package br.com.fiap.layouts;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void linear(View view) {

        Toast.makeText(this, R.string.LineayLayout, Toast.LENGTH_SHORT).show();
    }

    public void relative(View view) {

        Intent it = new Intent(this, RelativeActivity.class);
        startActivity(it);
    }


    public void absolute(View view) {

        Intent ab = new Intent(this, AbsoluteActivity.class);
        startActivity(ab);
    }

    public void frame(View view) {

        Intent fr = new Intent(this, FrameActivity.class);

        startActivity(fr);

    }
}
